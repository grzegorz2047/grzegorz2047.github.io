fx_version 'bodacious'
game 'gta5'

author 'You'
version '1.0.0'

fxdk_watch_command 'npm run' {'watch'}
fxdk_build_command 'npm run' {'build'}

client_script 'dist/client.js'
server_script 'dist/server.js'
