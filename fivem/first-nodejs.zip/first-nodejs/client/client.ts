on('onClientGameTypeStart', () => {
    emit('chat:addMessage', {
        args: [
          'Test wiadomosci!~'
        ]
      });
  });
