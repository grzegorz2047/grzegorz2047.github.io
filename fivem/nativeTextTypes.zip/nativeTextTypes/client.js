Delay = (ms) => new Promise(res => setTimeout(res, ms));

function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['SYSTEM', textToShow]
    });
}

function nativeMessage(lineOne, lineTwo = "", lineThree = "", duration = 5000, makeSound = true) {
    BeginTextCommandDisplayHelp("THREESTRINGS")
    AddTextComponentSubstringPlayerName(lineOne)
    AddTextComponentSubstringPlayerName(lineTwo)
    AddTextComponentSubstringPlayerName(lineThree)

    // shape (always 0), loop (bool), makeSound (bool), duration (5000 max 5 sec)
    EndTextCommandDisplayHelp(0, false, makeSound, duration)
}

function notify(text, isImportant = true) {
    SetNotificationTextEntry("STRING")
    AddTextComponentString(text)
    DrawNotification(isImportant, false)
}
const refreshTime = 0;
const X_KEY_BUTTON = 154;
const RIGHT_MOUSE_BUTTON = 25;
setTick(async () => {
    const ped = PlayerPedId();
    while(true) {    
        await Delay(refreshTime);
        if (IsControlJustPressed(0, RIGHT_MOUSE_BUTTON)) {
            nativeMessage("Co tam wciskasz za myche?")
        }
        if (IsControlJustPressed(0, X_KEY_BUTTON)) {  
            notify('Wcisnales X!');
        }
        if(IsControlJustReleased(0, X_KEY_BUTTON)) {
            //text('Pusciles klawisz X');
        }
    }
})