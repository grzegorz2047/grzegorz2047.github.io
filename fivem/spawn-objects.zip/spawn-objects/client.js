const spawnPos = [686.245, 577.950, 130.461];
Delay = (ms) => new Promise(res => setTimeout(res, ms));

on('onClientGameTypeStart', () => {
    exports.spawnmanager.setAutoSpawnCallback(() => {
      exports.spawnmanager.spawnPlayer({
        x: spawnPos[0],
        y: spawnPos[1],
        z: spawnPos[2],
        model: 'a_m_m_skater_01'
      }, () => {
        emit('chat:addMessage', {
          args: [
            'Welcome to the party!~'
          ]
        })
      });
    });
  
    exports.spawnmanager.setAutoSpawn(true)
    exports.spawnmanager.forceRespawn()
  });

async function main(key, coord, human) {

  const modelHash = GetHashKey(key);
  
  RequestModel(modelHash);
  while (!HasModelLoaded(modelHash))
  {
    await Delay(500);
  }
  
  // Create a vehicle at the player's position
  const obj = CreateObject(modelHash, coord[0], coord[1], coord[2] -1, true);
  const heading  = GetEntityHeading(human)
  console.log(heading)
  SetEntityHeading(obj, heading)
  }
  

function text(textToShow) {
  emit('chat:addMessage', {
      color: [255, 0, 0],
      multiline: true,
      args: ['SYSTEM', textToShow]
  });
}
const refreshTime = 0;
const ped = PlayerPedId();

const X_KEY_BUTTON = 154;
 setTick(async () => {
     while(true) {    
        await Delay(refreshTime);
        if(IsControlJustReleased(0, X_KEY_BUTTON)) {
            const coords = GetEntityCoords(ped);
            main("hei_prop_hei_warehousetrolly", coords, ped)
            text('Dodano rampe');
        }
    }
})


// async function Main() {
//     

//     if (!HasModelLoaded(modelHash)) {
//         // If the model isnt loaded we request the loading of the model and wait that the model is loaded
//         RequestModel(modelHash);
//         do {
//             new Promise(resolve => setTimeout(resolve, 100));
//         } while (!HasModelLoaded(modelHash));
//     }

//     // At this moment the model its loaded, so now we can create the object
//     const obj = CreateObject(modelHash, spawnPos[0], spawnPos[1], spawnPos[2], true);
// }

// Main();


 