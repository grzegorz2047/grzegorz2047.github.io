fx_version 'bodacious'
game 'gta5'

author 'grzegorz2047'
version '1.0.0'

client_scripts {
    'classes/vector3.js',
    'classes/blip-renderer.js',
    'client.js' 
}
server_script 'server.js'
shared_script 'shared.js'
