const spawnPos = new Vector3(686.245, 577.950, 130.461);

const blipRenderer = new BlipRenderer(spawnPos, 'spawn', {sprite: 108, color: 2, scale: 1});
blipRenderer.render();
const secondBlip = new BlipRenderer(new Vector3(606.245, 507.950, 100.461), 'spawn', {sprite: 442, color: 8, scale: 1});
secondBlip.render();