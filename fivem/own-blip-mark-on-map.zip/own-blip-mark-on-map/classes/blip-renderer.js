class BlipRenderer {

    center;
    blipName;

    constructor(center, blipName, blipSettings) {
        this.center = center;
        this.blipName = blipName;
        this.sprite = blipSettings.sprite;
        this.color = blipSettings.color;
        this.scale = blipSettings.scale;
         
    }

    render() {
        const blip = AddBlipForCoord(this.center.x, this.center.y, this.center.z);
        SetBlipSprite(blip, this.sprite);
        SetBlipColour(blip, this.color);
        SetBlipScale(blip, this.scale);
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(this.blipName);
        EndTextCommandSetBlipName(blip);
    }
}