function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['SYSTEM', textToShow]
    });
}
function errorParams() {
    text('Wprowadzono niepoprawne argumenty komendy!');
}
 
RegisterCommand("mod",  (source, args, rawCommand) => {
    const ped = PlayerPedId();
    if(args.length < 1) {
        errorParams();
        return;
    }
    const modType = args[0];
    if(!IsPedInAnyVehicle(ped)) {
        text('Aby to wykonac, musisz byc w aucie!');
        return;
    }
    const playersVehicle = GetVehiclePedIsIn(ped);

    if(modType === 'repair') {
        SetVehicleFixed(playersVehicle);
        SetVehicleDirtLevel(playersVehicle, 0);
        text('Pojazd został pomyślnie naprawiony!');
        return;
    }
    else if(modType === 'color') {
        if(args.length >= 4) { 
            const [r, g, b] = [parseInt(args[1]), parseInt(args[2]), parseInt(args[3])]
            if(isNaN(r) || isNaN(g) || isNaN(b)) {
                text('Parametry koloru muszą być liczbą!');
                return;
            } 
            SetVehicleCustomPrimaryColour(playersVehicle, r, g, b)
            SetVehicleCustomSecondaryColour(playersVehicle, r, g, b)
            text('Pojazd został poprawnie przemalowany!')
        } else {
            errorParams();
        }
    } else {
        errorParams();
    }
}, false);