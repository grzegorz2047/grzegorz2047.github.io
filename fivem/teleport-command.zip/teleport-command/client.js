function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['SYSTEM', textToShow]
    });
}
function simpleTeleport(playerPed, x, y, z) {
    SetPedCoordsKeepVehicle(playerPed, x, y, z)
}

function isPlayerSending(source) {
    return source > 0;
}
function errorParams() {
    text("Podaj poprawne wspolrzedne!");
}

RegisterCommand("tep",  (source, args, rawCommand) => {
    const ped = PlayerPedId();
    console.log(args.length);
    const hasEnoughArguments = args.length >= 3;
    if(hasEnoughArguments) {
        const x = parseFloat(args[0]);
        const y = parseFloat(args[1]);
        const z = parseFloat(args[2]);
        if(isNaN(x) || isNaN(y) || isNaN(z)) {
            errorParams();
            return;
        } else {
            console.log(x, y, z);
            simpleTeleport(ped, x, y, z);
            text("Pomyslnie przeteleportowano!");
        }
    } else {
        errorParams();
    }
}, false)