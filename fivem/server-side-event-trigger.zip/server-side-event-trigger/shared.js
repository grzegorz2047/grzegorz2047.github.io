const Delay = (ms) => new Promise(res => setTimeout(res, ms))
const spawnPos = new Vector3(686.245, 577.950, 130.461);

function GetDistanceBetweenCoords(x1, y1, x2, y2) {
    return Math.hypot(x2 - x1, y2 - y1);
}
