
function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['SYSTEM', textToShow]
    });
}

on('onClientGameTypeStart', () => {
    console.log("client started!")
    exports.spawnmanager.setAutoSpawnCallback(() => {
      exports.spawnmanager.spawnPlayer({
        x: spawnPos.x,
        y: spawnPos.y,
        z: spawnPos.z,
        model: 'a_m_m_skater_01'
      }, () => {
        text('zalogowano~');
      });
    });
  
    exports.spawnmanager.setAutoSpawn(true)
    exports.spawnmanager.forceRespawn()
  });

onNet('grzegorz2047:server-side-event-trigger:fromSpawnDistance', (distance, d) => {
    text('dystans od spawnu ' + distance);
})