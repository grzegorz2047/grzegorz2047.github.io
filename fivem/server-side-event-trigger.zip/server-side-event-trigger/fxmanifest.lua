fx_version 'bodacious'
game 'gta5'

author 'You'
version '1.0.0'

client_script 'client.js'
server_script 'server.js'
shared_scripts { 
    'vector3.js',
    'shared.js'

}
