setTick(async () => {
    for(let pedId = 1; pedId <= GetNumPlayerIndices(); pedId++) {
        const sourcePlayerCoords = GetEntityCoords(GetPlayerPed(pedId));
        const currentDistance = GetDistanceBetweenCoords(sourcePlayerCoords[0], sourcePlayerCoords[1], spawnPos.x, spawnPos.y);
        emitNet("grzegorz2047:server-side-event-trigger:fromSpawnDistance", pedId, currentDistance);
    }    
    await Delay(1000);
})