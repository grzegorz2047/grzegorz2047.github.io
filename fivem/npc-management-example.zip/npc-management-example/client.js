function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['Me', textToShow]
    });
}

async function animateNpc(pedRef, x, y, z) {
    RequestAnimDict("mini@strip_club@private_dance@part2");
    while (!HasAnimDictLoaded("mini@strip_club@private_dance@part2")) {
        await Delay(100);
    }
    const scene = CreateSynchronizedScene(x, y, z, 0.0, 0.0, 0.0, 2);
    //https://alexguirre.github.io/animations-list/
    TaskSynchronizedScene(pedRef, scene, "mini@strip_club@private_dance@part2", "priv_dance_p2", 1.0, -4.0, 261, 0, 0);
    SetSynchronizedSceneLooped(scene, 1);
}

async function setNpcAttributes(pedRef) {
    SetBlockingOfNonTemporaryEvents(pedRef, false);
    SetPedCombatAttributes(pedRef, CombatAttributes.BF_CanUseCover , true);
    SetPedCombatAttributes(pedRef, CombatAttributes.BF_CanFightArmedPedsWhenNotArmed, true);
    SetPedFleeAttributes(pedRef, 0, true);
    FreezeEntityPosition(pedRef, false);
    SetEntityInvincible(pedRef, false);
}

async function initPed(pedModel, coords, heading) {
    const hash = GetHashKey(pedModel);
    const x = coords[0];
    const y = coords[1];
    const z = coords[2];
    
    text('1');
    RequestModel(hash);
    while (!HasModelLoaded(hash))
    {
      await Delay(500);
    }
    text('2');
    const newPed = CreatePed("PED_TYPE_CIVFEMALE", hash, x, y, z, heading, true, false)
    setNpcAttributes(newPed);
    animateNpc(newPed, x, y, z);
    SetModelAsNoLongerNeeded(pedModel);
    text('3');
}


Delay = (ms) => new Promise(res => setTimeout(res, ms));

const ped = PlayerPedId();
const coords = GetEntityCoords(ped);

const task = setTick(async () => {
    await Delay(5000);
    await initPed('a_c_chimp', coords, 180.0);
    clearTick(task);
})

