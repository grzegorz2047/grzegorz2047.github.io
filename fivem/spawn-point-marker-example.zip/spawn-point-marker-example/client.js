Delay = (ms) => new Promise(res => setTimeout(res, ms));

class vector3 {
    x;
    y;
    z;

    constructor(x, y, z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

}
const spawnPos = new vector3(686.245, 577.950, 130.461);
on('onClientGameTypeStart', () => {
    exports.spawnmanager.setAutoSpawnCallback(() => {
      exports.spawnmanager.spawnPlayer({
        x: spawnPos.x,
        y: spawnPos.y,
        z: spawnPos.z,
        model: 'a_m_m_skater_01'
      }, () => {
        emit('chat:addMessage', {
          args: [
            'zalogowano~'
          ]
        })
      });
    });
  
    exports.spawnmanager.setAutoSpawn(true)
    exports.spawnmanager.forceRespawn()
  });


function drawMarker(pointOnMap, markerType, markerSize) {
    //https://docs.fivem.net/docs/game-references/markers/
    DrawMarker(markerType, pointOnMap.x, pointOnMap.y, pointOnMap.z, 0.0, 0.0, 0.0, 0.0, 0.0, 20.0, markerSize, markerSize, markerSize, 204, 204, 0, 100, true, false, 2, false, false, false, false);
}

const INVERTED_TRIANGLE_ID = 0;
const ROUND_MARKER_ID = 26;
const areaSize = 5;

setTick(async () => {

    while(true) {
        await Delay(0);
        drawMarker(spawnPos, ROUND_MARKER_ID, areaSize);
    }
});