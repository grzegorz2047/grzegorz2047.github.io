"use strict"; 
  //https://www.se7ensins.com/forums/threads/weapon-and-explosion-hashes-list.1045035/
function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['SYSTEM', textToShow]
    });
}
function giveWeaponToPed(playerPed, weaponHash, amount) {
    GiveWeaponToPed(playerPed, weaponHash, amount, false, true);
}
RegisterCommand("give", (source, args, rawCommand) => {
    const playerPed = PlayerPedId()
    if(args.length == 0) {
        text("Za malo argumentow!");
        return;
    }
    const weaponHash = GetHashKey(args[0]);
    if(!IsWeaponValid(weaponHash)) {
        text("Niepoprawna nazwa broni do dania");
        return;
    }
    if(args.length == 1) {
        giveWeaponToPed(playerPed, weaponHash, 100);
        text('Pomyslnie dodano bron!');
    }
    else if(args.length == 2) {
        const amount = parseInt(args[1]);

        if(isNaN(amount)) {
            text("Niepoprawna ilosc amunicji!");
            return;
        }
        if(amount < 0) {
            text("Nie mozna dac amunicji umnie!");
            return;
        }
        giveWeaponToPed(playerPed, weaponHash, amount);
        text('Pomyslnie dodano bron!');
    }
    
}, false)