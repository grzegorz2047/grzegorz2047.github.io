Delay = (ms) => new Promise(res => setTimeout(res, ms));

function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['SYSTEM', textToShow]
    });
}

const refreshTime = 0;
const X_KEY_BUTTON = 154;
const RIGHT_MOUSE_BUTTON = 25;
setTick(async () => {
    const ped = PlayerPedId();
    while(true) {    
        await Delay(refreshTime);
        if (IsControlJustPressed(0, RIGHT_MOUSE_BUTTON)) {
            text('Na kogo sie czaisz?');
        }
        if (IsControlJustPressed(0, X_KEY_BUTTON)) {  
            text('Wcisnales X');
        }
        if(IsControlJustReleased(0, X_KEY_BUTTON)) {
            text('Pusciles klawisz X');
        }
    }
})