Delay = (ms) => new Promise(res => setTimeout(res, ms));
const spawnPos = new Vector3(686.245, 577.950, 130.461);

on('onClientGameTypeStart', () => {
    exports.spawnmanager.setAutoSpawnCallback(() => {
      exports.spawnmanager.spawnPlayer({
        x: spawnPos.x,
        y: spawnPos.y,
        z: spawnPos.z,
        model: 'a_m_m_skater_01'
      }, () => {
        emit('chat:addMessage', {
          args: [
            'zalogowano~'
          ]
        })
      });
    });
  
    exports.spawnmanager.setAutoSpawn(true)
    exports.spawnmanager.forceRespawn()
  });



const text3d = new Text3dRenderer(spawnPos, "Spawn", {fontId: 2, scale: 1});
const aboveSpawnPos = Object.assign({}, spawnPos);
aboveSpawnPos.z += 8;
const higher3d = new Text3dRenderer(aboveSpawnPos, "Nad Spawnem", {fontId: 2, scale: 1});

setTick(async () => {

    while(true) {
        await Delay(0);
        text3d.render();
        higher3d.render();
    }
});