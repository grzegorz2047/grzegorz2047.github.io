class Text3dRenderer {

    center;
    
    constructor(center, textToDraw, text3dSettings) {
        this.center = center;
        this.textToDraw = textToDraw;
        this.fontId = text3dSettings.fontId;
        this.scale = text3dSettings.scale;
    }

    draw3DText(x, y, z, textToDraw, fontId, scaleX, scaleY) {
        const [px, py, pz] = GetGameplayCamCoords();
        const dist = GetDistanceBetweenCoords(px, py, pz, x, y, z, 1)
    
        let scale = (1 / dist) * 20;
        const fov = (1 / GetGameplayCamFov()) * 100;
        scale = scale * fov;
        const [onScreen, _x, _y] = [World3dToScreen2d(x, y, z)]
    
        if (onScreen) {
            SetTextScale(scaleX * scale, scaleY * scale);
            SetTextFont(fontId);
            SetTextProportional(1);
            SetTextColour(255, 255, 255, 150);
            SetTextDropshadow(1, 1, 1, 0, 255);
            SetTextEdge(2, 0, 0, 0, 220);
            SetTextDropShadow();
            SetTextOutline();
            SetTextEntry("STRING");
            SetTextCentre(1);
            AddTextComponentString(textToDraw);
            SetDrawOrigin(x, y, z + 2, 0);
            DrawText(0.0, 0.0);
            ClearDrawOrigin();
        }   
    }

    render() {
        this.draw3DText(this.center.x, this.center.y, this.center.z, this.textToDraw, this.fontId, this.scale, this.scale)
    }
}