Delay = (ms) => new Promise(res => setTimeout(res, ms));

class vector3 {
    x;
    y;
    z;

    constructor(x, y, z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

}
const spawnPos = new vector3(686.245, 577.950, 130.461);
on('onClientGameTypeStart', () => {
    exports.spawnmanager.setAutoSpawnCallback(() => {
      exports.spawnmanager.spawnPlayer({
        x: spawnPos.x,
        y: spawnPos.y,
        z: spawnPos.z,
        model: 'a_m_m_skater_01'
      }, () => {
        emit('chat:addMessage', {
          args: [
            'zalogowano~'
          ]
        })
      });
    });
  
    exports.spawnmanager.setAutoSpawn(true)
    exports.spawnmanager.forceRespawn()
  });


function drawMarker(pointOnMap, markerType, markerSize) {
    //https://docs.fivem.net/docs/game-references/markers/
    DrawMarker(markerType, pointOnMap.x, pointOnMap.y, pointOnMap.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, markerSize, markerSize, markerSize, 204, 204, 0, 100, false, false, 2, false, false, false, false);
}

let spawnMarkerPosition = Object.assign({}, spawnPos)
let spawnMarkerDeviation = 1.5; 
let spawnMarkerAnimationFrame = 0;
const TRIANGLE_MARKER_ID = 7;

function drawSpawnAnimatedMarker() {
    drawMarker(spawnMarkerPosition, TRIANGLE_MARKER_ID, 2);
}
setTick(async () => { //https://smashingmagazine.com/2011/10/quick-look-math-animations-javascript/
    while(spawnMarkerAnimationFrame < 100) {
        spawnMarkerAnimationFrame+= 0.01;
        spawnMarkerPosition.z = spawnPos.z + 2 + (Math.sin(spawnMarkerAnimationFrame) * spawnMarkerDeviation) ;
       
        //console.log(spawnMarkerPosition.z);
        await Delay(5);
    }
    spawnMarkerAnimationFrame = -100;
    console.log('hop');
 });
setTick(async () => {

    while(true) {
        await Delay(0);
        drawSpawnAnimatedMarker();
    }
});