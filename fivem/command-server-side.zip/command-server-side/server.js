"use strict"; 

function serverText(source, text) {
    emitNet('chat:addMessage', source, {
        color: [5, 255, 255],
        multiline: true,
        args: [GetPlayerName(source), text]
    });
}

function isPlayerSending(source) {
    return source > 0;
}
RegisterCommand("ping",  (source, args, rawCommand) => {
    if (isPlayerSending(source)) {
        //serverText(source, 'PONG!');
        //serverText(source, 'Params: ' + args);
       //serverText(source, 'all in: ' + rawCommand);
        console.log(args.length);
        if(args.length >= 1) {
            if(args[0] === 'pong') {
                serverText(source,'PING!');
            }
        }
    }
    else {
        console.log("Ta komenda została wykonana przez server console, RCON client, or a resource.")
    }
}, false)
