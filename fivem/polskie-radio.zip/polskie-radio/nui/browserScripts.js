const songs = [
    {url: 'https://staremelodie.pl/mp3/Moja_ukochana_wyk_Ulatowski_1666479444.mp3', title:'Moja ukochana'},
    {url: 'https://staremelodie.pl/mp3/La_Conga_1494796658.mp3', title:'La Conga'},
    {url: 'https://staremelodie.pl/mp3/Gdy_kobiecie_jest_zle_1487110149.mp3', title:'Gdy kobiecie jest źle'},
    {url: 'https://staremelodie.pl/mp3/A_ja_to_gwizdze_na_to_1596053742.mp3', title:'A ja to gwiżdżę na to'},
    {url: 'https://staremelodie.pl/mp3/Kochaj_tylko_mnie_1469324624.mp3', title:'Kochaj tylko mnie'}
    ];
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}

let currentlyPlaying;
function stopPlaying() {
    if(currentlyPlaying) {
        currentlyPlaying.currentTime = 0;
        currentlyPlaying.pause();
    }
    document.getElementById('currentlyPlaying').style.visibility = 'hidden';
}

function playCarRadio() {
    stopPlaying();
    const musicToPlay = songs[getRandomInt(songs.length)];
    currentlyPlaying = new Audio(musicToPlay.url);
    currentlyPlaying.addEventListener("ended", function() {
        stopPlaying();
        playCarRadio();
        console.log("ended");
    });
    currentlyPlaying.play();
    console.log("Odgrywam " + musicToPlay.title);
    musicDisplayLabelElement = document.getElementById('currentlyPlaying');
    musicDisplayLabelElement.style.visibility = 'visible';
    musicDisplayLabelElement.textContent = "Aktualnie odtwarzane: " + musicToPlay.title;

}
function updateRadioMusic(enabled) {
    if(enabled) {
        playCarRadio();
    } else {
        console.log('Konczę grać!')
        stopPlaying();
    }
}
$(function() {
	window.onload = (e) => {
        console.log('loaded');
		window.addEventListener('message', (event) => {
			var item = event.data;
			if (item !== undefined && item.type === "radio") {
                console.log('radio odpalaj na ' + item.enabled)
                updateRadioMusic(item.enabled);
			}
		});
	};
});