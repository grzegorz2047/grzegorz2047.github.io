RegisterServerEvent("grzechuAPI:updateRadioStatus")
RegisterServerEvent('baseevents:enteredVehicle')
RegisterServerEvent('baseevents:leftVehicle')

on('baseevents:enteredVehicle', (currentVehicle, currentSeat, vehicleDisplayName) => {
    console.log("enter ", currentVehicle, currentSeat, vehicleDisplayName);
    const isEnabled = true;
    const pId = source;
    emitNet("grzechuAPI:updateRadioStatus", pId, isEnabled, currentVehicle, currentSeat, vehicleDisplayName); 

});

on('baseevents:leftVehicle', (currentVehicle, currentSeat, vehicleDisplayName) => {
    console.log("left ", currentVehicle, currentSeat, vehicleDisplayName);
    const isEnabled = false;
    const pId = source;
    emitNet("grzechuAPI:updateRadioStatus", pId, isEnabled, currentVehicle, currentSeat, vehicleDisplayName); 
});