function sendRadioState(isEnabled) {
    console.log('wysylam dane!')
    SendNUIMessage({
        type: "radio",
        enabled: isEnabled
    })
}


onNet('grzechuAPI:updateRadioStatus', (isEnabled, currentVehicle, currentSeat, vehicleDisplayName) => {
    console.log('Dostaje zdarzenie!');
    sendRadioState(isEnabled);
    if(isEnabled) {
        SetVehRadioStation(currentVehicle, "OFF")
    }
});