Delay = (ms) => new Promise(res => setTimeout(res, ms));

function text(textToShow) {
    emit('chat:addMessage', {
        color: [255, 0, 0],
        multiline: true,
        args: ['Me', textToShow]
    });
}

const refreshTime = 1 * 1000;
setTick(async () => {
    const ped = PlayerPedId();
    const coords = GetEntityCoords(ped);
    const output = 'Koordy |' + coords[0].toFixed(4) + ' |  ' 
    + coords[1].toFixed(4) + ' |  ' 
    + coords[2].toFixed(4);
    //text(output);
    console.log(output)
    await Delay(refreshTime);
})