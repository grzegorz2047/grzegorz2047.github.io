console.log("[rest-test] Server Resource Started");
  import fetch from 'node-fetch';

    function getAuthToken() {
        return '';
    }

    async function sendData(url = '', _method= 'get', data = {}) {
        // Default options are marked with *
        let requestData = { 
            method: _method, // *GET, POST, PUT, DELETE, etc.
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json',
                'Authorization' : getAuthToken()
                // 'Content-Type': 'application/x-www-form-urlencoded',
            },
        }
        if(_method === 'GET') {
            delete requestData['body'];
        }
        const response = await fetch(url, requestData);
        return response;
  }

  
  
on('playerConnecting', (name:string, setKickReason:any, deferrals:any) => {
    console.log('player join');
    deferrals.defer()

    const player:string = String(global.source);
    setTimeout(() => {
        deferrals.update(`Hello ${name}. Your ID is being checked.`)
         // pretend to be a wait
        setTimeout(() => {
            console.log("1");
            sendData('http://localhost:8080/user' + '?name=' + name, 'GET')
            .then((data) => {
                console.log("2");
                let jsonStatus = data.status;
                if(jsonStatus !== 204) {
                    data.text().then(x=> {
                        console.log(x);
                        deferrals.done();
                    });               
                } else {
                    sendData('http://localhost:8080/user','POST', { 'name': name, email: 'test123qwe@gmail.com' })
                    .then((data) => {
                        console.log("3");
                        console.log(data.status); // JSON data parsed by `data.json()` call
                        deferrals.done();
                    }).catch(err => {
                        deferrals.done("Blad~!");
                    });
                }
                console.log("5");
                //trigger event with data  
            }, (reason)=> {
                console.log(reason);
                deferrals.done("Blad~!");
            });
            
        }, 0)
    }, 0)
})
    