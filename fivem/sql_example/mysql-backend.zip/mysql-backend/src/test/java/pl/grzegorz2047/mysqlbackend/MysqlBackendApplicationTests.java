package pl.grzegorz2047.mysqlbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysqlBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
