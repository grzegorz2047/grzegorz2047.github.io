package pl.grzegorz2047.mysqlbackend.sql.user.repository;

import org.springframework.data.repository.CrudRepository;
import pl.grzegorz2047.mysqlbackend.sql.User;

import java.util.Optional;

public interface UserRepository extends CrudRepository<User, Integer> {
    Optional<User> findByName(String name);
}
