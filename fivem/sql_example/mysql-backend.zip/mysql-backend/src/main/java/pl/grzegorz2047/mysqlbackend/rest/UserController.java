package pl.grzegorz2047.mysqlbackend.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import pl.grzegorz2047.mysqlbackend.sql.User;
import pl.grzegorz2047.mysqlbackend.sql.user.dto.UserDTO;
import pl.grzegorz2047.mysqlbackend.sql.user.repository.service.UserService;

import java.util.Optional;

@Controller // This means that this class is a Controller
@RequestMapping(path = "/user") // This means URL's start with /demo (after Application path)
public class UserController {

    @Autowired
    UserService userService;


    @PostMapping(path = "")
    public @ResponseBody ResponseEntity<User> addNewUser(@RequestBody UserDTO user) {
        // @ResponseBody means the returned String is the response, not a view name
        // @RequestParam means it is a parameter from the GET or POST request
        boolean saved = userService.saveUser(user.getName(), user.getEmail());
        if (saved) {
            return ResponseEntity.ok().body(new User());
        }
        return ResponseEntity.ok().body(new User());
    }

    @GetMapping(path = "")
    public @ResponseBody ResponseEntity<User> getUser(@RequestParam String name) {
        Optional<User> userData = userService.getUserData(name);
        return userData.map(user -> new ResponseEntity<>(user, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NO_CONTENT));
    }
}