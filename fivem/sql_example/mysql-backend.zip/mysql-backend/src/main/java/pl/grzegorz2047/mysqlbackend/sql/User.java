package pl.grzegorz2047.mysqlbackend.sql;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private long id;

    private String fivemIdentifier;
    private String name;

    private Integer kills;

    private Integer death;

    private String email;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getKills() {
        return kills;
    }

    public void setKills(Integer kills) {
        this.kills = kills;
    }

    public Integer getDeath() {
        return death;
    }

    public void setDeath(Integer death) {
        this.death = death;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        boolean checkIsIgnoreUserNameCases = name.equalsIgnoreCase(user.name);

        return Objects.equals(id, user.id) && Objects.equals(fivemIdentifier, user.fivemIdentifier) && checkIsIgnoreUserNameCases && Objects.equals(kills, user.kills) && Objects.equals(death, user.death) && Objects.equals(email, user.email);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, fivemIdentifier, name, kills, death, email);
    }
}
